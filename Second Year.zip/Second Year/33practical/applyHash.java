
import java.io.FileNotFoundException;
import java.io.IOException;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author southgate
 */
public class applyHash {



public static void main(String args[]) throws FileNotFoundException, IOException{
    
    Hash run = new Hash();
    run.main(args);
    Hashan run1 = new Hashan();
    run1.main(args);




}
}

