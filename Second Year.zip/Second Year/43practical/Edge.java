
public class Edge {
	
	    public double weight;
	    public Vertex destination;
	 
	    public Edge(Vertex destination, double weight) {
	        this.destination = destination;
	        this.weight = weight;
	    }
	
}
