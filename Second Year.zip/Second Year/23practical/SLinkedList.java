


public interface SLinkedList {

	public void displayList();
	public int length();
	public void addANodeToStart(String dataItem);
	public void deleteHeadNode();
	public boolean isOnList(String dataItem);
	
	
}
