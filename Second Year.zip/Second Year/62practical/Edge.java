
public class Edge {

	 public double distance;
	    public Node target;
	 
	    public Edge(Node Target, double Distance) {
	        this.target = Target;
	        this.distance = Distance;
	    }
	
	
	
}
