


public class Test {
public static void main(String [] args){
	
	
	for(int i=0;i<1;i++){
	Huffman2 test = new Huffman2();
	test.main(args);
}
	

}
}
